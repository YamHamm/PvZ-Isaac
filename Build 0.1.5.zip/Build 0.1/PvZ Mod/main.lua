local mod = RegisterMod("PVZ", 1)
local game = Game()
local sound = SFXManager()
local rng = RNG()
local rundata = {}
function mod:npcupdate(npc)
	if npc.Type == 10 and npc.Variant == 1 and npc:GetData().coneheadgaper_chance == nil then
		npc:GetData().coneheadgaper_chance = true
		if npc:GetDropRNG():RandomInt(5) == 1 then
			npc:Remove()
			Isaac.Spawn(10, 1, 1, npc.Position, Vector(0,0), nil)
		end
	end
end

mod:AddCallback(ModCallbacks.MC_NPC_UPDATE, mod.npcupdate)